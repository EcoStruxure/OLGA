package demo.example;

import java.util.Date;
import java.util.Set;

import org.eclipse.rdf4j.rio.RDFFormat;
import org.eclipse.rdf4j.rio.Rio;

import demoexample.global.util.GLOBAL;
import demoexample.rdf.model.Building;
import demoexample.rdf.model.Floor;
import demoexample.rdf.model.Humidity;
import demoexample.rdf.model.HumidityUnit;
import demoexample.rdf.model.IFloor;
import demoexample.rdf.model.IHumidity;
import demoexample.rdf.model.ISensor;
import demoexample.rdf.model.ITemperature;
import demoexample.rdf.model.ITemperatureUnit;
import demoexample.rdf.model.IUnitOfMeasure;
import demoexample.rdf.model.Sensor;
import demoexample.rdf.model.Temperature;
import demoexample.rdf.model.TemperatureUnit;


public class Example {


	public static void main(String[] args) {
		createTopology();
		serialize();
		printAllFloors();
	}

	public static void createTopology()
	{
		String ns = "http://www.example.com#";
		//Create a floor 1
		IFloor floor1 = new Floor(ns, "f1");
		floor1.setName("floor 1");

		//Create a floor 2
		Floor floor2 = new Floor(ns, "f2");
		floor2.setName("floor 2");

		//Create a Building 1
		Building building1 = new Building(ns, "b1");
		building1.setDescription("North face Building");
		building1.setName("b1");
		building1.addFloors(floor1); //add floor 1
		building1.addFloors(floor2);

		//Create a Temperature measurement
		ITemperature temp1 = new Temperature(ns, "t1");
		temp1.setDescription("this is indoor temperature");
		ITemperatureUnit celsius = new TemperatureUnit(ns, "Celsius");
		temp1.addUnitOfMeasure(celsius);
		temp1.setName("temp1");
		temp1.setTimeStamp((new Date()));
		temp1.setValue(32);

		//Create a Temperature Sensor
		ISensor temperatureSensor = new Sensor(ns, "s1");
		temperatureSensor.setDescription("This is sensor s1");
		temperatureSensor.setName("TempSensor1");
		temperatureSensor.addMeasures(temp1);
		temperatureSensor.addPhysicalLocation(floor1);

		//Create a Humidity measurement
		IHumidity humidity1 = new Humidity(ns, "h1");
		humidity1.setDescription("this is indoor humidity");
		IUnitOfMeasure relativeHumidity = new HumidityUnit(ns, "relativeHumidity");
		humidity1.addUnitOfMeasure(relativeHumidity);
		humidity1.setName("h1");
		humidity1.setTimeStamp((new Date()));
		humidity1.setValue(64);

		//Create a Humidity Sensor
		ISensor humiditySensor = new Sensor(ns, "hum1");
		humiditySensor.setDescription("This is humidity sensor 1");
		humiditySensor.setName("hum1");
		humiditySensor.addMeasures(humidity1);
		humiditySensor.addPhysicalLocation(floor2);
	}


	public static void serialize()
	{
		Rio.write(GLOBAL.model, System.out, RDFFormat.TURTLE);
	}

	public static void printAllFloors()
	{
		Set<IFloor> floors = Floor.getAllFloorsObjectsCreated();
		for(IFloor floor : floors)
		{
			System.out.println(floor.getName());
		}
	}

}