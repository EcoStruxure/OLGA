from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

class PhysicalLocation(rdfSubject):
    rdf_type = Namespace('http://www.example.com/').PhysicalLocation
    
    setID = rdfSingle(Namespace('http://www.example.com/').hasID)
    setDescription = rdfSingle(Namespace('http://www.example.com/').hasDescription)
    setName = rdfSingle(Namespace('http://www.example.com/').hasName)

