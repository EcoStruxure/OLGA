from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.www.example.com.PhysicalLocation import PhysicalLocation



class Area(PhysicalLocation):
    rdf_type = Namespace('http://www.example.com/').Area
    

