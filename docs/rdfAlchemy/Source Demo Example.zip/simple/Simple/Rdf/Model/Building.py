from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.Simple.Rdf.Model.PhysicalLocation import PhysicalLocation



class Building(PhysicalLocation):
    rdf_type = Namespace('http://www.example.com/').Building
    

    FloorsFloor = rdfList(Namespace('http://www.example.com/').FloorsFloor)
    listOfFloorsFloor = []
    
    def addFloors(self, parameter):
        self.listOfFloorsFloor.append(parameter)
        self.FloorsFloor = self.listOfFloorsFloor
