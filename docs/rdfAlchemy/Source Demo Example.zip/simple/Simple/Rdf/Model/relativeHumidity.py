from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.Simple.Rdf.Model.UnitOfMeasure import UnitOfMeasure

class relativeHumidity(UnitOfMeasure):
    rdf_type = Namespace('http://www.example.com/').HumidityUnit

