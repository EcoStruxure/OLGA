from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList




class UnitOfMeasure(rdfSubject):
    rdf_type = Namespace('http://www.example.com/').UnitOfMeasure
    

