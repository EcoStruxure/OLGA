from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.www.example.com.Node import Node



class Edge(Node):
    rdf_type = Namespace('http://www.example.com/').Edge
    

