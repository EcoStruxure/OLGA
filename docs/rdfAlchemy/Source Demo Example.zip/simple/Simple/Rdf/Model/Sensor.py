from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.Simple.Rdf.Model.Node import Node



class Sensor(Node):
    rdf_type = Namespace('http://www.example.com/').Sensor
    

