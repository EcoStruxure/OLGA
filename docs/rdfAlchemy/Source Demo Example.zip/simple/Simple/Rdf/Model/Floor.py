from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.Simple.Rdf.Model.PhysicalLocation import PhysicalLocation



class Floor(PhysicalLocation):
    rdf_type = Namespace('http://www.example.com/').Floor
    

    SectorsSector = rdfList(Namespace('http://www.example.com/').SectorsSector)
    listOfSectorsSector = []
    
    def addSectors(self, parameter):
        self.listOfSectorsSector.append(parameter)
        self.SectorsSector = self.listOfSectorsSector
    RoomsRoom = rdfList(Namespace('http://www.example.com/').RoomsRoom)
    listOfRoomsRoom = []
    
    def addRooms(self, parameter):
        self.listOfRoomsRoom.append(parameter)
        self.RoomsRoom = self.listOfRoomsRoom
