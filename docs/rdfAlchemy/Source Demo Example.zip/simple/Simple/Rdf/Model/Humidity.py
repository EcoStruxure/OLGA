from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.Simple.Rdf.Model.Measurement import Measurement



class Humidity(Measurement):
    rdf_type = Namespace('http://www.example.com/').Humidity
    

    UnitOfMeasureHumidityUnit = rdfList(Namespace('http://www.example.com/').UnitOfMeasureHumidityUnit)
    listOfUnitOfMeasureHumidityUnit = []
    
    def addUnitOfMeasure(self, parameter):
        self.listOfUnitOfMeasureHumidityUnit.append(parameter)
        self.UnitOfMeasureHumidityUnit = self.listOfUnitOfMeasureHumidityUnit
