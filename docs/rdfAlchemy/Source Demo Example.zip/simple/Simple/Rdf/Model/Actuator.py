from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.www.example.com.Node import Node



class Actuator(Node):
    rdf_type = Namespace('http://www.example.com/').Actuator
    

