from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.Simple.Rdf.Model.PhysicalLocation import PhysicalLocation



class Sector(PhysicalLocation):
    rdf_type = Namespace('http://www.example.com/').Sector
    

