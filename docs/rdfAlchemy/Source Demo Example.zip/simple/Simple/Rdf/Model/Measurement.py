from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList




class Measurement(rdfSubject):
    rdf_type = Namespace('http://www.example.com/').Measurement
    
    setName = rdfSingle(Namespace('http://www.example.com/').hasName)
    setValue = rdfSingle(Namespace('http://www.example.com/').hasValue)
    setDescription = rdfSingle(Namespace('http://www.example.com/').hasDescription)
    setTimeStamp = rdfSingle(Namespace('http://www.example.com/').hasTimeStamp)

    UnitOfMeasureUnitOfMeasure = rdfList(Namespace('http://www.example.com/').UnitOfMeasureUnitOfMeasure)
    listOfUnitOfMeasureUnitOfMeasure = []
    
    def addUnitOfMeasure(self, parameter):
        self.listOfUnitOfMeasureUnitOfMeasure.append(parameter)
        self.UnitOfMeasureUnitOfMeasure = self.listOfUnitOfMeasureUnitOfMeasure
