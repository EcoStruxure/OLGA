from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.www.example.com.Measurement import Measurement



class Luminosity(Measurement):
    rdf_type = Namespace('http://www.example.com/').Luminosity
    

    UnitOfMeasureLuminosityUnit = rdfList(Namespace('http://www.example.com/').UnitOfMeasureLuminosityUnit)
    listOfUnitOfMeasureLuminosityUnit = []
    
    def addUnitOfMeasure(self, parameter):
        self.listOfUnitOfMeasureLuminosityUnit.append(parameter)
        self.UnitOfMeasureLuminosityUnit = self.listOfUnitOfMeasureLuminosityUnit
