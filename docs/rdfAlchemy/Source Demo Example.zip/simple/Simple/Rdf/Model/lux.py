from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.www.example.com.UnitOfMeasure import UnitOfMeasure

class lux(UnitOfMeasure):
    rdf_type = Namespace('http://www.example.com/').LuminosityUnit

