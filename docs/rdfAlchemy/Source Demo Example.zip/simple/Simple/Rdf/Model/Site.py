from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.Simple.Rdf.Model.PhysicalLocation import PhysicalLocation



class Site(PhysicalLocation):
    rdf_type = Namespace('http://www.example.com/').Site
    

    BuildingsBuilding = rdfList(Namespace('http://www.example.com/').BuildingsBuilding)
    listOfBuildingsBuilding = []
    
    def addBuildings(self, parameter):
        self.listOfBuildingsBuilding.append(parameter)
        self.BuildingsBuilding = self.listOfBuildingsBuilding
