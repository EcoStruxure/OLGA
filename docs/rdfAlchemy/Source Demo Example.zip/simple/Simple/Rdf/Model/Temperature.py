from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList

from simple.Simple.Rdf.Model.Measurement import Measurement



class Temperature(Measurement):
    rdf_type = Namespace('http://www.example.com/').Temperature
    

    UnitOfMeasureTemperatureUnit = rdfList(Namespace('http://www.example.com/').UnitOfMeasureTemperatureUnit)
    listOfUnitOfMeasureTemperatureUnit = []
    
    def addUnitOfMeasure(self, parameter):
        self.listOfUnitOfMeasureTemperatureUnit.append(parameter)
        self.UnitOfMeasureTemperatureUnit = self.listOfUnitOfMeasureTemperatureUnit
