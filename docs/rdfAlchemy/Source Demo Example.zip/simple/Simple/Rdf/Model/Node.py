from rdflib import Namespace
from rdfalchemy.rdfSubject import rdfSubject
from rdfalchemy import rdfSingle, rdfMultiple, rdfList




class Node(rdfSubject):
    rdf_type = Namespace('http://www.example.com/').Node
    
    setID = rdfSingle(Namespace('http://www.example.com/').hasID)
    setName = rdfSingle(Namespace('http://www.example.com/').hasName)
    setDescription = rdfSingle(Namespace('http://www.example.com/').hasDescription)

    ConnectsToNode = rdfList(Namespace('http://www.example.com/').ConnectsToNode)
    listOfConnectsToNode = []
    
    def addConnectsTo(self, parameter):
        self.listOfConnectsToNode.append(parameter)
        self.ConnectsToNode = self.listOfConnectsToNode
    PhysicalLocationPhysicalLocation = rdfList(Namespace('http://www.example.com/').PhysicalLocationPhysicalLocation)
    listOfPhysicalLocationPhysicalLocation = []
    
    def addPhysicalLocation(self, parameter):
        self.listOfPhysicalLocationPhysicalLocation.append(parameter)
        self.PhysicalLocationPhysicalLocation = self.listOfPhysicalLocationPhysicalLocation
    MeasuresMeasurement = rdfList(Namespace('http://www.example.com/').MeasuresMeasurement)
    listOfMeasuresMeasurement = []
    
    def addMeasures(self, parameter):
        self.listOfMeasuresMeasurement.append(parameter)
        self.MeasuresMeasurement = self.listOfMeasuresMeasurement
