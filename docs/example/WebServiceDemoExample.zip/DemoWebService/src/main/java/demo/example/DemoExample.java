package demo.example;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.codec.Charsets;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

public class DemoExample {

  /**
   * @param args the command line arguments
   * @throws com.mashape.unirest.http.exceptions.UnirestException
   * @throws java.io.FileNotFoundException
   */
  public static void main(String[] args) throws UnirestException, FileNotFoundException, IOException {
    
    
    // Call the generate library endpoint
    String code = "cs"; String library = "trinity";
    //String code = "java"; String library = "rdf4j";
    //String code = "python"; String library = "rdfalchemy";
    
    HttpResponse<InputStream> response = Unirest
            .post("http://localhost:9090/Ontology/OLGAsaas/1.0.0/1.0/generate?code=" + code + "&name=simple&library=" +library)
            //.post("http://localhost:9090/Ontology/OLGAsaas/1.0.0/1.0/generate?preserve=true&code=" + code + "&name=simple&library=" +library)
            //.post("http://localhost:9090/Ontology/OLGAsaas/1.0.0/1.0/generate?skipCompile=true&code=" + code + "&name=simple&library=" +library)
            .header("Content-Type", "application/xml")
            .body(FileUtils.readFileToString(new File("src/main/resources/simple.owl"), Charsets.UTF_8))
            .asBinary();

    //Get the result as a zip file
    File zipFile = new File("generated.zip");
    zipFile.createNewFile();
    try (FileOutputStream out = new FileOutputStream(zipFile)) {
      IOUtils.copy(response.getBody(), out);
    }
    
    //Call the collect logs endpoint
    HttpResponse<InputStream> responseCollect = Unirest
            .get("http://localhost:9090/Ontology/OLGAsaas/1.0.0/1.0/admin/collectlogs")
            .asBinary();

    //Get the result as a zip file
    File zipFileCollect = new File("collectedLogs.zip");
    zipFileCollect.createNewFile();
    try (FileOutputStream out = new FileOutputStream(zipFileCollect)) {
      IOUtils.copy(responseCollect.getBody(), out);
    }

    //Call the clear logs endpoint
    //Unirest.get("http://localhost:9090/Ontology/OLGAsaas/1.0.0/1.0/admin/clearlogs");

    
  }

}
